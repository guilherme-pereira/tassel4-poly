/**
 * The modelfitter package contains classes that use various methods to fit multiple variant sites to a GWAS model. All of the classes do model selection.
 */
/**
 * @author pbradbury
 *
 */
package net.maizegenetics.gwas.modelfitter;