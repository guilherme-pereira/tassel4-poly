/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.maizegenetics.tutorial;

/**
 *
 * @author edbuckler
 */
public class BasicTasselOperations {
    
    public static void main(String[] args) {
        //        for (int site = 0; site < inputAlign.getSiteCount(); site++) {
//            int position=inputAlign.getPositionInLocus(site);
//            System.out.print(site+"\t"+position);
//            for (int taxon = 0; taxon < inputAlign.getSequenceCount(); taxon++) {
//                byte genotype=inputAlign.getBase(taxon, site);
//                System.out.print("\t"+NucleotideAlignmentConstants.getNucleotideIUPAC(genotype));
//            }
//            System.out.println("");
//        }
//        BitSet mj= inputAlign.getAllelePresenceForAllSites(0,0);
//        mj.cardinality();
//        BitSet mn= inputAlign.getAllelePresenceForAllSites(0,1);
//        mj.intersect(mn);
//        OpenBitSet.intersectionCount(mj, mn);
    }
    
}
